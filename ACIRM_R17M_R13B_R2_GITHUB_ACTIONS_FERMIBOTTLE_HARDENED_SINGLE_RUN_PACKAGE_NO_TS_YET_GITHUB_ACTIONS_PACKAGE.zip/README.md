# ACIRM_R17M_R13B_R2_GITHUB_ACTIONS_FERMIBOTTLE_HARDENED_SINGLE_RUN_PACKAGE_NO_TS_YET

Hardened GitHub Actions package for ACIRM R13B_R2 FermiBottle starter likelihood/TS attempt. Not proof.
