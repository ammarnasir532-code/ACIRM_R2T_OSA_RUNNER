# ACIRM_R17M_R13B_R2_GITHUB_ACTIONS_FERMIBOTTLE_HARDENED_SINGLE_RUN_PACKAGE_NO_TS_YET

هذه حزمة GitHub Actions مصححة ومشددة لتشغيل محاولة Fermitools/TS starter في السحابة، لا على الهاتف.

## أهم الإصلاحات
- لا نستخدم `docker --user`؛ وبعد Docker نستخدم `sudo chown` لإصلاح ملكية الملفات.
- نستخدم `curl -fL --retry` لتنزيل ملفات HEASARC داخل Actions.
- يوجد `always upload artifact` حتى عند الفشل.
- يوجد `R13B_R2_STAGE_STATUS.tsv` و`R13B_R2_PRELIMINARY_RESULT.json` بدل الاعتماد على keyword matching.
- لا يوجد Xvfb/display.
- توجد `timeout` لكل مرحلة.
- لا تدخل FITS الكبيرة في artifact النهائي.

## الاستخدام
فك الضغط في جذر مستودع GitHub، ثم شغل workflow:
`ACIRM R13B R2 FermiBottle hardened single run`

بعد الانتهاء حمّل artifact:
`ACIRM_R17M_R13B_R2_FERMITOOLS_HARDENED_RESULTS`

## السقف
حتى إذا ظهر TS فهو starter فقط: `STARTER_MODEL_ONLY_PENDING_4FGL_COMPLETION`, `NOT_PROOF`.
