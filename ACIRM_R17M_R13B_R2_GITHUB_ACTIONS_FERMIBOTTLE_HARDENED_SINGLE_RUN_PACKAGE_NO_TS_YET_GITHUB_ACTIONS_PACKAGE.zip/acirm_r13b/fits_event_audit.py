import sys, pathlib, json, datetime
out={'created_utc':datetime.datetime.utcnow().replace(microsecond=0).isoformat()+'Z','claim':'EVENT_COUNT_AUDIT_NOT_TS','files':[]}
try:
    from astropy.io import fits
    for path in sys.argv[1:]:
        p=pathlib.Path(path); item={'file':str(p),'exists':p.exists(),'size_bytes':p.stat().st_size if p.exists() else None}
        if p.exists():
            with fits.open(p, memmap=True) as hdul:
                for i,h in enumerate(hdul):
                    if getattr(h,'data',None) is not None:
                        try: item.setdefault('table_hdus',[]).append({'hdu':i,'name':h.name,'rows':len(h.data),'columns':list(getattr(h,'columns',[]).names or [])[:20]})
                        except Exception: pass
        out['files'].append(item)
except Exception as e: out['error']=repr(e)
pathlib.Path('results/R13B_R2_EVENT_FILE_AUDIT.json').write_text(json.dumps(out,indent=2))
