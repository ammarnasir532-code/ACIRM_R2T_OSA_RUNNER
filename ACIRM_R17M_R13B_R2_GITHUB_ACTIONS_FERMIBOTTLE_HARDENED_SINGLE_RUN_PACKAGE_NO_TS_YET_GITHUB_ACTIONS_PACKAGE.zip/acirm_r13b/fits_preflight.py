import sys, json, pathlib, datetime
status={'created_utc':datetime.datetime.utcnow().replace(microsecond=0).isoformat()+'Z','claim':'FITS_PREFLIGHT_NOT_TS'}
try:
    from astropy.io import fits
    status['astropy_available']=True; files=[]
    for path in sys.argv[1:]:
        p=pathlib.Path(path); item={'file':str(p),'exists':p.exists(),'size_bytes':p.stat().st_size if p.exists() else None}
        if p.exists():
            with fits.open(p, memmap=True) as hdul:
                item['nhdu']=len(hdul); item['hdu_names']=[getattr(h,'name','') for h in hdul]
        files.append(item)
    status['files']=files; status['pass']=all(x.get('exists') and x.get('nhdu',0)>0 for x in files)
except Exception as e:
    status['astropy_available']=False; status['error']=repr(e); status['pass']=False
pathlib.Path('results/R13B_R2_FITS_PREFLIGHT.json').write_text(json.dumps(status,indent=2))
if not status.get('pass'): raise SystemExit(4)
