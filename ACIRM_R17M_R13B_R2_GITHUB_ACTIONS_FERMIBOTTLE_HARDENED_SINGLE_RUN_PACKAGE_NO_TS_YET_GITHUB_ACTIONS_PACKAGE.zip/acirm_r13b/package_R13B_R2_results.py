from pathlib import Path
import zipfile, hashlib, json, datetime, csv
ROOT=Path('.'); FINAL=ROOT/'final_artifact'; FINAL.mkdir(exist_ok=True)
def sha256_file(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for b in iter(lambda:f.read(1024*1024), b''): h.update(b)
    return h.hexdigest()
result_path=ROOT/'results'/'R13B_R2_PRELIMINARY_RESULT.json'
if not result_path.exists():
    docker_status=(ROOT/'results'/'DOCKER_EXIT_STATUS.txt').read_text(errors='replace').strip() if (ROOT/'results'/'DOCKER_EXIT_STATUS.txt').exists() else 'MISSING'
    out={'created_utc':datetime.datetime.utcnow().replace(microsecond=0).isoformat()+'Z','decision':'R13B_R2_DOCKER_OR_PRE_TS_STAGE_DID_NOT_COMPLETE_LOGS_READY_NOT_PROOF','docker_exit_status':docker_status,'claim_ceiling':['NO_TS_CONFIRMED','LOGS_ONLY','NOT_PROOF']}
    (ROOT/'results').mkdir(exist_ok=True); result_path.write_text(json.dumps(out,indent=2))
zip_path=FINAL/'ACIRM_R17M_R13B_R2_FERMITOOLS_HARDENED_RESULTS.zip'; manifest=[]
with zipfile.ZipFile(zip_path,'w',compression=zipfile.ZIP_DEFLATED) as z:
    for folder in ['acirm_r13b','results','logs']:
        p=ROOT/folder
        if not p.exists(): continue
        for f in sorted(p.rglob('*')):
            if not f.is_file(): continue
            if f.suffix.lower() in ['.fits','.fit','.gz'] and f.stat().st_size > 10_000_000:
                manifest.append({'file':str(f),'size_bytes':f.stat().st_size,'included':False,'reason':'large_fits_excluded_from_slim_artifact'}); continue
            z.write(f, arcname=str(f)); manifest.append({'file':str(f),'size_bytes':f.stat().st_size,'included':True,'sha256':sha256_file(f)})
sha=sha256_file(zip_path); (FINAL/(zip_path.name+'.sha256.txt')).write_text(sha+'  '+zip_path.name+'\n')
with open(FINAL/'R13B_R2_ARTIFACT_MANIFEST.csv','w',newline='',encoding='utf-8') as fp:
    fields=['file','size_bytes','included','sha256','reason']; w=csv.DictWriter(fp, fieldnames=fields, extrasaction='ignore'); w.writeheader(); w.writerows(manifest)
status={'created_utc':datetime.datetime.utcnow().replace(microsecond=0).isoformat()+'Z','zip':zip_path.name,'sha256':sha,'decision_source':'results/R13B_R2_PRELIMINARY_RESULT.json','claim':'R13B_R2_ARTIFACT_READY_LOGS_OR_STARTER_TS_NOT_PROOF'}
(FINAL/'R13B_R2_ARTIFACT_STATUS.json').write_text(json.dumps(status,indent=2))
print('ZIP',zip_path); print('SHA256',sha)
