import pathlib, json, re, datetime, xml.etree.ElementTree as ET
res=pathlib.Path('results'); logs=pathlib.Path('logs')
stage_text=(res/'R13B_R2_STAGE_STATUS.tsv').read_text(errors='replace') if (res/'R13B_R2_STAGE_STATUS.tsv').exists() else ''
gtlog=(logs/'gtlike_afterglow.log').read_text(errors='replace') if (logs/'gtlike_afterglow.log').exists() else ''
exit_status=(res/'GTLIKE_EXIT_STATUS.txt').read_text(errors='replace').strip() if (res/'GTLIKE_EXIT_STATUS.txt').exists() else 'MISSING'
fit_xml=res/'fit_afterglow_output.xml'; source_rows=[]
if fit_xml.exists():
    try:
        root=ET.parse(fit_xml).getroot()
        for src in root.findall('source'):
            source_rows.append({'name':src.attrib.get('name'),'TS_attribute':src.attrib.get('TS') or src.attrib.get('ts')})
    except Exception as e: source_rows.append({'parse_error':repr(e)})
lines=[]
for line in gtlog.splitlines():
    low=line.lower()
    if 'grb221009a' in low or 'test statistic' in low or re.search(r'\bts\b', low) or 'error' in low or 'exception' in low: lines.append(line[:500])
decision='R13B_R2_FERMITOOLS_STARTER_TS_ATTEMPT_COMPLETED_REQUIRES_R14_AUDIT_NOT_PROOF' if exit_status=='0' and fit_xml.exists() else 'R13B_R2_FERMITOOLS_STARTER_TS_ATTEMPT_INCOMPLETE_OR_FAILED_LOGS_READY_NOT_PROOF'
out={'created_utc':datetime.datetime.utcnow().replace(microsecond=0).isoformat()+'Z','decision':decision,'gtlike_exit_status':exit_status,'fit_xml_exists':fit_xml.exists(),'srcmaps_exists':(res/'srcmaps_afterglow.fits').exists(),'stage_status_tail':stage_text.splitlines()[-50:],'source_rows_from_fit_xml':source_rows,'candidate_log_lines':lines[:200],'claim_ceiling':['STARTER_MODEL_ONLY','NEARBY_4FGL_SOURCES_NOT_INCLUDED','NOT_PUBLISHABLE_TS','NOT_SOURCE_ATTRIBUTION_PROOF','NOT_ACIRM_PROOF']}
(res/'R13B_R2_PRELIMINARY_RESULT.json').write_text(json.dumps(out,indent=2))
