import json, shutil, pathlib, datetime, sys
cfg_path=pathlib.Path('acirm_r13b/R13B_RUN_CONFIG.json'); model_path=pathlib.Path('acirm_r13b/R13B_STARTER_MODEL_GRB221009A_DIFFUSE_ONLY_PENDING_4FGL.xml')
required=['gtselect','gtmktime','gtbin','gtltcube','gtexpcube2','gtsrcmaps','gtlike','curl','python']
rows=[{'tool':t,'path':shutil.which(t),'available':shutil.which(t) is not None} for t in required]
status={'created_utc':datetime.datetime.utcnow().replace(microsecond=0).isoformat()+'Z','tools':rows,'config_exists':cfg_path.exists(),'model_exists':model_path.exists(),'all_required_available':all(r['available'] for r in rows) and cfg_path.exists() and model_path.exists(),'claim':'ENVIRONMENT_PREFLIGHT_ONLY_NOT_TS'}
pathlib.Path('results').mkdir(exist_ok=True); pathlib.Path('results/R13B_R2_ENVIRONMENT_PREFLIGHT.json').write_text(json.dumps(status,indent=2))
if not status['all_required_available']: sys.exit(2)
