import pathlib, os, glob, json, sys, datetime
model_in=pathlib.Path('acirm_r13b/R13B_STARTER_MODEL_GRB221009A_DIFFUSE_ONLY_PENDING_4FGL.xml'); model_out=pathlib.Path('results/R13B_MODEL_RUNTIME.xml'); xml=model_in.read_text()
def find_file(name):
    roots=[]
    for env in ['FERMI_DIR','FERMI_DIFFUSE_DIR','HEADAS']:
        if os.environ.get(env): roots.append(os.environ[env])
    roots += ['/opt','/usr/local','/home','/work','/']
    seen=set()
    for root in roots:
        if not root or root in seen or not os.path.exists(root): continue
        seen.add(root)
        try: hits=glob.glob(os.path.join(root,'**',name), recursive=True)
        except Exception: hits=[]
        hits=[h for h in hits if os.path.isfile(h)]
        if hits: return hits[0]
    return None
gal=find_file('gll_iem_v07.fits'); iso=find_file('iso_P8R3_SOURCE_V3_v1.txt')
status={'created_utc':datetime.datetime.utcnow().replace(microsecond=0).isoformat()+'Z','gll_iem_v07.fits':gal,'iso_P8R3_SOURCE_V3_v1.txt':iso,'all_found':bool(gal and iso),'claim':'DIFFUSE_MODEL_DISCOVERY_NOT_TS'}
pathlib.Path('results/R13B_R2_DIFFUSE_MODEL_STATUS.json').write_text(json.dumps(status,indent=2))
if not gal or not iso: sys.exit(3)
xml=xml.replace('$(FERMI_DIR)/refdata/fermi/galdiffuse/gll_iem_v07.fits', gal).replace('$(FERMI_DIR)/refdata/fermi/galdiffuse/iso_P8R3_SOURCE_V3_v1.txt', iso)
model_out.write_text(xml)
