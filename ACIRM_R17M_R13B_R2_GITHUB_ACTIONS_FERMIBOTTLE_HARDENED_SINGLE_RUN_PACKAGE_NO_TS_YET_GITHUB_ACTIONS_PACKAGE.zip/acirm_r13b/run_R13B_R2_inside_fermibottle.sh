#!/usr/bin/env bash
set -u
mkdir -p data results logs tmp
exec > >(tee logs/R13B_R2_CONTAINER_STDOUT.log) 2> >(tee logs/R13B_R2_CONTAINER_STDERR.log >&2)

STAGE_FILE="results/R13B_R2_STAGE_STATUS.tsv"
: > "$STAGE_FILE"

ts_utc() { date -u +%Y-%m-%dT%H:%M:%SZ; }
record_stage() {
  local stage="$1"; local status="$2"; local detail="${3:-}"
  printf "%s\t%s\t%s\t%s\n" "$(ts_utc)" "$stage" "$status" "$detail" | tee -a "$STAGE_FILE"
}
fail_stage() {
  record_stage "$1" "FAIL" "$2"
  python acirm_r13b/write_decision_stub.py "$1" "$2" || true
  exit 20
}
run_step() {
  local stage="$1"; shift
  record_stage "$stage" "START" "$*"
  timeout --preserve-status 120m "$@"
  local s=$?
  if [ "$s" -ne 0 ]; then
    record_stage "$stage" "FAIL" "exit=$s command=$*"
    python acirm_r13b/write_decision_stub.py "$stage" "exit=$s command=$*" || true
    exit "$s"
  fi
  record_stage "$stage" "PASS" "exit=0"
}

record_stage "container_start" "PASS" "R13B_R2 hardened FermiBottle run"
date -u || true
pwd || true
ls -lah || true

if [ -f /opt/conda/etc/profile.d/conda.sh ]; then
  source /opt/conda/etc/profile.d/conda.sh
  conda activate fermi || true
fi
if ! command -v gtselect >/dev/null 2>&1; then
  if command -v conda >/dev/null 2>&1; then
    conda activate fermi || true
  fi
fi

{
  echo "PATH=$PATH"
  echo "FERMI_DIR=${FERMI_DIR:-}"
  command -v conda || true
  conda info --envs || true
  for t in gtselect gtmktime gtbin gtltcube gtexpcube2 gtsrcmaps gtlike fkeyprint fv python curl; do
    printf "%s\t" "$t"; command -v "$t" || true
  done
} | tee logs/R13B_R2_ENVIRONMENT_INVENTORY.txt

python acirm_r13b/preflight_environment.py || fail_stage "preflight_environment" "required tool or config missing"
record_stage "preflight_environment" "PASS" "required commands/config OK"

python - <<'PYECHO'
import json, pathlib
cfg=json.load(open('acirm_r13b/R13B_RUN_CONFIG.json'))
pathlib.Path('results/R13B_R2_LOCKED_CONFIG_ECHO.json').write_text(json.dumps(cfg,indent=2))
PYECHO

PHOTON_URL=$(python - <<'PYURL'
import json
print(json.load(open('acirm_r13b/R13B_RUN_CONFIG.json'))['lat_inputs']['photon_url'])
PYURL
)
SPACECRAFT_URL=$(python - <<'PYURL'
import json
print(json.load(open('acirm_r13b/R13B_RUN_CONFIG.json'))['lat_inputs']['spacecraft_url'])
PYURL
)
PHOTON="data/$(basename "$PHOTON_URL")"
SPACECRAFT="data/$(basename "$SPACECRAFT_URL")"

download_file() {
  local url="$1"; local dest="$2"; local label="$3"
  if [ -s "$dest" ] && [ "$(stat -c%s "$dest")" -gt 1000000 ]; then
    record_stage "download_${label}" "PASS" "reuse $dest bytes=$(stat -c%s "$dest")"
    return 0
  fi
  rm -f "$dest"
  record_stage "download_${label}" "START" "$url"
  curl -fL --retry 5 --retry-delay 10 --connect-timeout 30 --speed-time 60 --speed-limit 1024 -o "$dest" "$url"
  local s=$?
  if [ "$s" -ne 0 ]; then
    fail_stage "download_${label}" "curl failed exit=$s url=$url"
  fi
  if [ ! -s "$dest" ] || [ "$(stat -c%s "$dest")" -le 1000000 ]; then
    fail_stage "download_${label}" "downloaded file too small: $dest"
  fi
  record_stage "download_${label}" "PASS" "bytes=$(stat -c%s "$dest") sha256=$(sha256sum "$dest" | awk '{print $1}')"
}

download_file "$PHOTON_URL" "$PHOTON" "photon"
download_file "$SPACECRAFT_URL" "$SPACECRAFT" "spacecraft"
python acirm_r13b/write_download_manifest.py "$PHOTON" "$PHOTON_URL" "$SPACECRAFT" "$SPACECRAFT_URL" || true

python acirm_r13b/resolve_diffuse_models.py || fail_stage "resolve_diffuse_models" "diffuse model discovery failed"
record_stage "resolve_diffuse_models" "PASS" "runtime XML written"

python acirm_r13b/fits_preflight.py "$PHOTON" "$SPACECRAFT" || fail_stage "fits_preflight" "FITS preflight failed"
record_stage "fits_preflight" "PASS" "FITS files readable"

RA="288.2646"
DEC="19.7735"
RAD="12.0"
EMIN="100.0"
EMAX="500000.0"
ZMAX="90.0"
EVCLASS="128"
EVTYPE="3"
IRFS="P8R3_SOURCE_V3"
NXPIX="240"
NYPIX="240"
BINSZ="0.1"
ENUMBINS="30"
TMIN="687014824.987530"
TMAX="687187024.987530"
MODEL="results/R13B_MODEL_RUNTIME.xml"

for t in gtselect gtmktime gtbin gtltcube gtexpcube2 gtsrcmaps gtlike; do
  punlearn "$t" >/dev/null 2>&1 || true
done

run_step "gtselect" gtselect infile="$PHOTON" outfile="results/events_afterglow_selected.fits" ra="$RA" dec="$DEC" rad="$RAD" tmin="$TMIN" tmax="$TMAX" emin="$EMIN" emax="$EMAX" zmax="$ZMAX" evclass="$EVCLASS" evtype="$EVTYPE" chatter=2
run_step "gtmktime" gtmktime scfile="$SPACECRAFT" filter="(DATA_QUAL>0)&&(LAT_CONFIG==1)" roicut=yes evfile="results/events_afterglow_selected.fits" outfile="results/events_afterglow_gti.fits" chatter=2
python acirm_r13b/fits_event_audit.py results/events_afterglow_selected.fits results/events_afterglow_gti.fits || true
run_step "gtbin_ccube" gtbin evfile="results/events_afterglow_gti.fits" scfile="$SPACECRAFT" outfile="results/ccube_afterglow.fits" algorithm=CCUBE nxpix="$NXPIX" nypix="$NYPIX" binsz="$BINSZ" coordsys=CEL xref="$RA" yref="$DEC" axisrot=0 proj=AIT ebinalg=LOG emin="$EMIN" emax="$EMAX" enumbins="$ENUMBINS" chatter=2
run_step "gtltcube" gtltcube evfile="results/events_afterglow_gti.fits" scfile="$SPACECRAFT" outfile="results/ltcube_afterglow.fits" dcostheta=0.025 binsz=1 chatter=2
run_step "gtexpcube2" gtexpcube2 infile="results/ltcube_afterglow.fits" cmap=none outfile="results/bexpmap_afterglow.fits" irfs="$IRFS" nxpix="$NXPIX" nypix="$NYPIX" binsz="$BINSZ" coordsys=CEL xref="$RA" yref="$DEC" axisrot=0 proj=AIT ebinalg=LOG emin="$EMIN" emax="$EMAX" enumbins="$ENUMBINS" chatter=2
run_step "gtsrcmaps" gtsrcmaps scfile="$SPACECRAFT" expcube="results/ltcube_afterglow.fits" cmap="results/ccube_afterglow.fits" srcmdl="$MODEL" bexpmap="results/bexpmap_afterglow.fits" outfile="results/srcmaps_afterglow.fits" irfs="$IRFS" chatter=2
record_stage "gtlike" "START" "starter binned likelihood"
timeout --preserve-status 120m gtlike statistic=BINNED optimizer=NEWMINUIT evfile="results/srcmaps_afterglow.fits" scfile="$SPACECRAFT" expcube="results/ltcube_afterglow.fits" srcmdl="$MODEL" sfile="results/fit_afterglow_output.xml" irfs="$IRFS" > logs/gtlike_afterglow.log 2>&1
GTLIKE_STATUS=$?
echo "$GTLIKE_STATUS" > results/GTLIKE_EXIT_STATUS.txt
if [ "$GTLIKE_STATUS" -ne 0 ]; then
  record_stage "gtlike" "FAIL" "exit=$GTLIKE_STATUS"
  python acirm_r13b/parse_R13B_R2_results.py || true
  python acirm_r13b/write_decision_stub.py "gtlike" "exit=$GTLIKE_STATUS" || true
  exit "$GTLIKE_STATUS"
fi
record_stage "gtlike" "PASS" "exit=0"
python acirm_r13b/parse_R13B_R2_results.py || true
record_stage "parse_results" "PASS" "parser completed"
