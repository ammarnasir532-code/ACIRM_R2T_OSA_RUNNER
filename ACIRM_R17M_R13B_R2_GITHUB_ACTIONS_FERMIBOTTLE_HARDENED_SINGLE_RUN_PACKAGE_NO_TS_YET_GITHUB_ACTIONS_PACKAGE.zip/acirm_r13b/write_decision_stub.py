import sys, json, pathlib, datetime
stage=sys.argv[1] if len(sys.argv)>1 else 'UNKNOWN_STAGE'; detail=sys.argv[2] if len(sys.argv)>2 else ''
out={'created_utc':datetime.datetime.utcnow().replace(microsecond=0).isoformat()+'Z','decision':'R13B_R2_FERMITOOLS_STARTER_TS_ATTEMPT_INCOMPLETE_OR_FAILED_LOGS_READY_NOT_PROOF','failed_stage':stage,'detail':detail,'claim_ceiling':['NO_TS_CONFIRMED','FAILURE_LOGS_ONLY','NOT_PROOF']}
pathlib.Path('results').mkdir(exist_ok=True); pathlib.Path('results/R13B_R2_PRELIMINARY_RESULT.json').write_text(json.dumps(out,indent=2))
