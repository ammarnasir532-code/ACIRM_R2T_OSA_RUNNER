import sys, pathlib, hashlib, json, datetime
def sha256_file(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for b in iter(lambda:f.read(1024*1024), b''): h.update(b)
    return h.hexdigest()
photon, photon_url, sc, sc_url = sys.argv[1:5]
rows=[]
for label,path,url in [('photon',photon,photon_url),('spacecraft',sc,sc_url)]:
    p=pathlib.Path(path); rows.append({'label':label,'file':str(p),'url':url,'size_bytes':p.stat().st_size if p.exists() else None,'sha256':sha256_file(p) if p.exists() else None})
out={'created_utc':datetime.datetime.utcnow().replace(microsecond=0).isoformat()+'Z','downloads':rows,'claim':'DOWNLOAD_MANIFEST_NOT_SCIENCE_EVIDENCE'}
pathlib.Path('results/R13B_R2_DOWNLOAD_MANIFEST.json').write_text(json.dumps(out,indent=2))
