# ACIRM R2T — حل الهاتف لتشغيل OSA عن بعد

## الفكرة
أنت تعمل على الهاتف، لذلك لا نشغّل OSA على الهاتف ولا داخل Colab إذا لم توجد أدوات OSA. هذه الحزمة تجعل الهاتف يقوم فقط برفع الملفات إلى GitHub، ثم GitHub Actions يشغّل Docker image الخاصة بـ INTEGRAL OSA ويعيد لك النتائج كـ artifact.

## الخطوات من الهاتف
1. افتح GitHub من المتصفح أو التطبيق.
2. أنشئ repository جديدًا مثل: `ACIRM_R2T_OSA_RUNNER`.
3. ارفع محتويات هذه الحزمة كما هي إلى المستودع، مع الحفاظ على مجلد `.github/workflows/`.
4. افتح تبويب **Actions**.
5. اختر workflow باسم: `ACIRM R2T OSA remote preflight`.
6. اضغط **Run workflow**.
7. بعد انتهاء التشغيل، افتح run ثم **Artifacts** وحمّل: `ACIRM_R21AX_R7G_R2T_RESULTS`.
8. ارفع artifact هنا للتدقيق.

## ماذا تفعل الحزمة؟
- تسحب Docker image: `integralsw/osa`.
- تفحص أوامر OSA داخل runtime.
- تتحقق من وصول بيانات SCW/AUX/IC/IDX/CAT.
- تنزّل ملفات SCW الأساسية للثماني نوافذ.
- تنتج ZIP + SHA.

## ماذا لا تفعل؟
- لا تعلن 511 discovery.
- لا ترفع نتيجة SPI_OPER إلى OSA proof.
- لا تعتبر فشل GitHub Actions فشلًا فيزيائيًا.

## السقف العلمي
`REMOTE_OSA_PREFLIGHT_OR_EXECUTION_ONLY_NOT_DISCOVERY_UNTIL_FULL_AUDIT`
