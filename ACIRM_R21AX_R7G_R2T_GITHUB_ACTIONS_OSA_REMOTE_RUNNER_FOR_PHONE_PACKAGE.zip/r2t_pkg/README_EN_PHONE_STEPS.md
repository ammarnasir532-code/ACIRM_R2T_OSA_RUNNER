# ACIRM R2T — Phone-only remote OSA runner package

This package lets a phone-only user launch an OSA preflight remotely via GitHub Actions. The phone only uploads the repository and downloads the resulting artifact.

Steps:
1. Create a GitHub repository.
2. Upload this package preserving `.github/workflows/`.
3. Open **Actions**.
4. Run `ACIRM R2T OSA remote preflight`.
5. Download artifact `ACIRM_R21AX_R7G_R2T_RESULTS`.
6. Upload the artifact back for audit.

Scientific ceiling: preflight/remote execution only. No 511 discovery or OSA proof until audited full OSA/SPIMODFIT outputs exist.
