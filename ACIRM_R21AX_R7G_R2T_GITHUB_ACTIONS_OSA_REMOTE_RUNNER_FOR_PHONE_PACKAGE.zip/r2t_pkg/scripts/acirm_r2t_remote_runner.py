#!/usr/bin/env python3
"""
ACIRM R21AX R7G R2T - GitHub Actions remote runner for phone-only workflow.
This script is designed to run either on GitHub-hosted Ubuntu or inside the OSA Docker container.
It performs a conservative preflight and produces a ZIP artifact. It does not claim discovery.
"""
import os, sys, json, csv, time, hashlib, zipfile, subprocess, shutil
from pathlib import Path
from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError

ROOT = Path(os.environ.get("ACIRM_R2T_WORKDIR", ".")).resolve()
OUT = ROOT / "acirm_r2t_results"
DATA = ROOT / "osa_data"
OUT.mkdir(parents=True, exist_ok=True)
DATA.mkdir(parents=True, exist_ok=True)
CONFIG = json.loads(Path("config/r2t_target_config.json").read_text(encoding="utf-8"))
RUN_ID = CONFIG["run_id"]
HEASARC_BASE = CONFIG["heasarc_base"].rstrip("/")
TARGET_REV = CONFIG["target_rev"]
TARGET_SCW_IDS = CONFIG["target_scw_ids"]
CLAIM_CEILING = CONFIG["claim_ceiling"]


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024*1024), b""):
            h.update(chunk)
    return h.hexdigest()


def write_csv(path, rows, fieldnames=None):
    rows = rows or []
    if fieldnames is None:
        keys = []
        for r in rows:
            for k in r.keys():
                if k not in keys:
                    keys.append(k)
        fieldnames = keys or ["empty"]
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        for r in rows:
            w.writerow({k: r.get(k, "") for k in fieldnames})


def write_json(path, obj):
    Path(path).write_text(json.dumps(obj, indent=2, sort_keys=True, default=str), encoding="utf-8")


def run(cmd, timeout=1800):
    print("$", cmd, flush=True)
    try:
        p = subprocess.run(cmd, shell=True, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=timeout)
        print(p.stdout[-8000:], flush=True)
        return {"cmd": cmd, "returncode": p.returncode, "stdout_tail": p.stdout[-8000:]}
    except Exception as e:
        print("EXCEPTION", repr(e), flush=True)
        return {"cmd": cmd, "returncode": "EXCEPTION", "stdout_tail": repr(e)}


def probe_url(url, timeout=60):
    row = {"url": url, "ok": False, "status_code": "", "content_length": "", "content_type": "", "error": ""}
    try:
        req = Request(url, method="HEAD", headers={"User-Agent": "ACIRM-R2T-Runner/1.0"})
        with urlopen(req, timeout=timeout) as r:
            row["status_code"] = getattr(r, "status", "")
            row["content_length"] = r.headers.get("content-length", "")
            row["content_type"] = r.headers.get("content-type", "")
            row["ok"] = 200 <= int(row["status_code"]) < 400
    except HTTPError as e:
        row["status_code"] = e.code
        row["error"] = str(e)
    except Exception as e:
        row["error"] = repr(e)
    return row


def download(url, dest, max_bytes=2_500_000_000):
    dest = Path(dest)
    dest.parent.mkdir(parents=True, exist_ok=True)
    row = {"url": url, "dest": str(dest), "ok": False, "bytes": 0, "sha256": "", "error": ""}
    if dest.exists() and dest.stat().st_size > 0:
        row.update({"ok": True, "bytes": dest.stat().st_size, "sha256": sha256_file(dest), "error": "already_exists"})
        return row
    try:
        req = Request(url, headers={"User-Agent": "ACIRM-R2T-Runner/1.0"})
        with urlopen(req, timeout=1800) as r:
            total = int(r.headers.get("content-length", "0") or 0)
            if total and total > max_bytes:
                row["error"] = f"too_large_{total}"
                return row
            tmp = dest.with_suffix(dest.suffix + ".part")
            done = 0
            with open(tmp, "wb") as f:
                while True:
                    chunk = r.read(1024*1024)
                    if not chunk:
                        break
                    done += len(chunk)
                    if done > max_bytes:
                        row["error"] = f"exceeded_{max_bytes}"
                        tmp.unlink(missing_ok=True)
                        return row
                    f.write(chunk)
            tmp.rename(dest)
        row.update({"ok": True, "bytes": dest.stat().st_size, "sha256": sha256_file(dest)})
    except Exception as e:
        row["error"] = repr(e)
    return row


def main():
    start = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    command_rows = []
    for c in ["og_create", "spi_science_analysis", "spiros", "spimodfit", "dal_verify", "docker"]:
        path = shutil.which(c)
        row = {"command": c, "found": bool(path), "path": path or ""}
        if path:
            row.update(run(f"{c} --version", timeout=30))
        command_rows.append(row)
    write_csv(OUT / "r2t_command_availability.csv", command_rows)

    probe_rows = []
    products = ["swg.fits", "spi_spectra.fits.gz", "spi_gti.fits.gz", "spi_oper.fits.gz"]
    for scw in TARGET_SCW_IDS:
        for product in products:
            url = f"{HEASARC_BASE}/scw/{TARGET_REV}/{scw}.001/{product}"
            r = probe_url(url)
            r.update({"scw_id": scw, "product": product})
            probe_rows.append(r)
    for branch in ["aux", "ic", "idx", "cat"]:
        url = f"{HEASARC_BASE}/{branch}/"
        r = probe_url(url)
        r.update({"branch": branch, "product": "BRANCH_ROOT"})
        probe_rows.append(r)
    write_csv(OUT / "r2t_data_reachability.csv", probe_rows)

    download_rows = []
    # Keep default download limited and safe: SCW group and SPI oper/spectra/gti only.
    for scw in TARGET_SCW_IDS:
        for product in products:
            url = f"{HEASARC_BASE}/scw/{TARGET_REV}/{scw}.001/{product}"
            dest = DATA / "scw" / TARGET_REV / f"{scw}.001" / product
            download_rows.append({**download(url, dest), "scw_id": scw, "product": product})
    write_csv(OUT / "r2t_target_data_download_manifest.csv", download_rows)

    osa_found = any(r.get("found") for r in command_rows if r["command"] in ["og_create", "spi_science_analysis", "spiros", "spimodfit"])
    scw_swg_ok = sum(1 for r in download_rows if r["product"] == "swg.fits" and r.get("ok"))
    data_ready = scw_swg_ok == len(TARGET_SCW_IDS)

    # This runner intentionally avoids claiming full OSA proof unless a later script actually executes OSA.
    if osa_found and data_ready:
        final_status = "R21AX_R7G_R2T_REMOTE_OSA_ENV_AND_DATA_READY_FOR_R2U_ACTUAL_OSA_COMMANDS_NO_511_YET"
    elif data_ready:
        final_status = "R21AX_R7G_R2T_REMOTE_DATA_READY_BUT_OSA_COMMANDS_NOT_IN_CURRENT_CONTEXT_NO_PHYSICAL_NULL"
    else:
        final_status = "R21AX_R7G_R2T_REMOTE_PREFLIGHT_PARTIAL_DATA_OR_ENV_NO_PHYSICAL_NULL"

    decision = {
        "run_id": RUN_ID,
        "created_utc": start,
        "final_status": final_status,
        "claim_ceiling": CLAIM_CEILING,
        "target_scw_count": len(TARGET_SCW_IDS),
        "scw_swg_download_ok_count": scw_swg_ok,
        "osa_command_found": bool(osa_found),
        "next_step": "R2U actual OSA command execution only if og_create/spi_science_analysis/spiros/spimodfit are available inside the chosen runtime."
    }
    write_json(OUT / "R2T_REMOTE_RUNNER_DECISION.json", decision)
    (OUT / "R2T_PHONE_SUMMARY_AR.txt").write_text(
        "R2T phone solution summary\n"
        "الهدف: تشغيل الفحص/التحضير على GitHub Actions أو أي Linux بعيد بدل الهاتف.\n"
        f"Final status: {final_status}\n"
        f"SCW swg downloaded: {scw_swg_ok}/{len(TARGET_SCW_IDS)}\n"
        f"OSA command found: {osa_found}\n"
        "هذه ليست نتيجة 511 وليست OSA proof.\n",
        encoding="utf-8"
    )

    zip_path = ROOT / f"{RUN_ID}_RESULTS.zip"
    if zip_path.exists():
        zip_path.unlink()
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:
        for p in OUT.rglob("*"):
            if p.is_file():
                z.write(p, p.relative_to(ROOT))
    sha = sha256_file(zip_path)
    (ROOT / f"{RUN_ID}_RESULTS.zip.sha256.txt").write_text(sha + "  " + zip_path.name + "\n", encoding="utf-8")
    print("FINAL_STATUS:", final_status)
    print("ZIP:", zip_path)
    print("SHA256:", sha)

if __name__ == "__main__":
    main()
