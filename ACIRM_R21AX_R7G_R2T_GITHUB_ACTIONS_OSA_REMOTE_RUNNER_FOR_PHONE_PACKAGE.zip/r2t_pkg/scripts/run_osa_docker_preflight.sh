#!/usr/bin/env bash
set -euo pipefail
# This runs the ACIRM R2T preflight inside the official INTEGRAL OSA Docker image if Docker is available.
# It is safe: no discovery claim, no full OSA line metric.
IMAGE="${ACIRM_OSA_IMAGE:-integralsw/osa:11.2-2-g667521a3-20220403-190332-refcat-43.0-OSA11.0-61-g9cb5a93}"
WORKDIR="$(pwd)"
echo "Using OSA image: ${IMAGE}"
docker pull "${IMAGE}"
docker run --rm \
  -v "${WORKDIR}:/work" \
  -w /work \
  "${IMAGE}" \
  bash -lc 'python3 scripts/acirm_r2t_remote_runner.py || python scripts/acirm_r2t_remote_runner.py'
